<?php

namespace rahatPay\Exceptions;
use Exception;

class PaymentException extends Exception
{

}
